Supplementary File S2 - leakage and transfer audit of two public meat image datasets
(manuscript Sections 2.2, 2.5, 3.1 and 3.2; Tables 2-4; Figures 2 and 3)

freshness_leakage_audit.py  one script; reproduces the validation-design numbers (Section 3.2)
results.json                all protocols for both datasets (official split, image-level,
                            hash-family, capture blocks 5-100, random groups 5/20/100;
                            five fold assignments each) and cross-dataset transfer
assignments_meat.csv        per image: split, file, class, running number, 256-bit pHash,
assignments_poultry.csv     hash family (T = 60 bits), capture blocks of 20 and 100
gap_curve.json              mean pHash distance by file-number gap (Figure 3d)
fig_leak_v8.py              draws Figure 3 (validation design) from results.json and gap_curve.json

Data (public):
  Red meat: Meat Freshness Image Dataset (Shanawad, Kaggle 2022);
            copy: git clone https://github.com/TheLohia/Phteven  -> data/raw/{train,test}
  Poultry:  Fresh and Rotten Poultry Meat Datasets (Kaggle, calvinsama); 1,300-image copy:
            git clone https://github.com/LinggarM/Poultry-Meat-Freshness-Classification-with-Transfer-Learning-using-ResNet
            -> dataset_citra_dada_ayam/dataset 200x200/{training,validation}
Run:
  python freshness_leakage_audit.py --meat Phteven/data/raw --poultry "<repo>/dataset_citra_dada_ayam/dataset 200x200" --out out/
  Optional: MNV3_WEIGHTS=<file> loads local ImageNet weights for timm tf_mobilenetv3_small_100.

Fine-tuning check (added):
finetune_audit.py           full fine-tuning of MobileNetV3-Small (160 px, 4 epochs, AdamW),
                            image-level / random-group-100 / capture-block-100 folds (seed 0; seeds 1-2 below)
                            and fine-tuned cross-dataset transfer
finetune_results.json       its results (accuracy, macro-F1, spoiled-as-fresh, confusion matrices)
Run:  python finetune_audit.py --meat Phteven/data/raw --poultry "<repo>/dataset_citra_dada_ayam/dataset 200x200" --out out/

Robustness checks (added in revision):
robustness_audit.py            null distribution: 20 random within-class groupings per block size
                               (20 and 100), compared with capture-order blocks; empirical
                               p = (1 + #null <= capture) / 21, smallest attainable 0.048.
                               Repeats every protocol with frozen ResNet-50 features
                               (timm resnet50.a1_in1k) and cross-dataset transfer.
robustness_results.json        its results for colour, MobileNetV3 and ResNet-50 features
finetune_audit.py              now takes --seed; run for seeds 0, 1 and 2
finetune_results_seed0/1/2.json  per-seed results (seed 0 also has cross-dataset transfer)
finetune_summary_3seeds.json   mean +/- SD over the three fold assignments
Run:
  python robustness_audit.py --meat Phteven/data/raw --poultry "<repo>/dataset_citra_dada_ayam/dataset 200x200" --out out/
  python finetune_audit.py ... --out out_s1/ --seed 1 --protocols image_level,capture_block_100 --no_cross

Third dataset and provenance leakage check (added in revision):
dataset3_audit.py              A) provenance leakage check on all three datasets: order test
                               (share of images whose nearest same-class pHash neighbour lies within
                               +/-5 places in within-class file order; 999 within-class permutations;
                               p = (1 + #perm >= observed)/1000) and near-duplicate share (<= 60 bits).
                               B) fruit set (zijianchen98/Fruit-freshness-detection-dataset): image-level
                               vs hash-family 5-fold CV vs 20 size-matched random regroupings, frozen
                               MobileNetV3 and ResNet-50 features. --three adds the normal class.
dataset3_results.json          binary fresh vs rotten (1,560 images) + check on meat and poultry
dataset3_results_3class.json   fresh / normal / rotten (1,894 images)
assignments_fruit*.csv         per image: file number, fruit, class, pHash, hash family
Data: git clone https://github.com/zijianchen98/Fruit-freshness-detection-dataset
Run:  python dataset3_audit.py --fruit <repo> --assign <dir with assignments_meat/poultry.csv> --out out/ [--three]

Revision note (strict threshold): the paper reports fruit near-copy families at T = 30 bits
(dataset3_results*_T30.json, assignments_fruit*_T30.csv; run with --T 30). At 60 bits the fruit
families also joined different fruit on similar plain backgrounds; the 60- and 40-bit runs are kept
for comparison (dataset3_results*.json, *_T40.json).
fig_examples.py   draws Figure 2 (example images) from the assignment files.
  python fig_examples.py --meat Phteven/data/raw --fruit <repo> --assign <dir> --d3 <dir> --out fig.png

Paneer-curry exact-copy audit (added in revision; Section 3.7 / Fig. 2d):
paneer_duplicates.py        MD5/SHA-256 of every file in the 'good' class, copy groups, and
                            1,000 random 80/20 splits (share of test files with an identical copy
                            in training). Data: https://doi.org/10.17632/4898ctyf5n.1 (CC BY 4.0).
paneer_good_checksums.csv   per file: name, bytes, MD5, SHA-256, copy group, group size
                            (500 files, 9 distinct; SHA-256 values match the repository listing).
  python paneer_duplicates.py <Good folder> out.csv
