import json,numpy as np,matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#888','axes.labelcolor':'#222','xtick.color':'#555','ytick.color':'#555'})
BLUE,ORANGE,GREY,AQUA='#2a78d6','#eb6834','#8a8a85','#1baf7a'
R=json.load(open('supp/out3/results.json')); G=json.load(open('supp/out2/gap_curve.json'))
Bs=[1,5,10,20,50,100]
def series(ds,fn):
    s=R[ds][fn]; cap=[s['image_level_5fold']['acc']*100]+[s[f'capture_block_{b}']['acc']*100 for b in Bs[1:]]
    rnd=[s['image_level_5fold']['acc']*100]+[s[f'random_group_{b}']['acc']*100 for b in (5,20,100)]
    return cap,rnd
fig,ax=plt.subplots(2,2,figsize=(7.2,5.6))
def style(a,title,lab):
    a.set_xscale('log'); a.set_xticks(Bs); a.set_xticklabels(Bs); a.minorticks_off()
    a.set_xlabel('Group size (images)'); a.set_title(title,fontsize=9); a.grid(axis='y',color='#e6e6e3',lw=0.6); a.set_axisbelow(True)
    a.text(-0.17,1.07,lab,transform=a.transAxes,fontweight='bold')
for a,(fn,c,title,lab,yl) in zip(ax[0],[('cnn',BLUE,'Red meat: frozen CNN','(a)',(84,100)),('colour',ORANGE,'Red meat: colour + texture','(b)',(80,93))]):
    cap,rnd=series('meat',fn)
    a.plot([1,5,20,100],rnd,ls='--',lw=1.5,color=GREY,marker='o',ms=4); a.plot(Bs,cap,lw=2,color=c,marker='o',ms=5)
    a.set_ylim(*yl); style(a,title,lab)
    a.text(100,rnd[-1]+0.5,'random',color=GREY,ha='right',va='bottom',fontsize=8); a.text(100,cap[-1]-0.5,'capture order',color='#222',ha='right',va='top',fontsize=8)
ax[0][0].set_ylabel('5-fold accuracy (%)')
a=ax[1][0]
for fn,c,name in (('cnn',BLUE,'CNN'),('colour',ORANGE,'colour')):
    cap,rnd=series('poultry',fn)
    a.plot([1,5,20,100],rnd,ls='--',lw=1.5,color=GREY,marker='o',ms=4); a.plot(Bs,cap,lw=2,color=c,marker='o',ms=5)
    a.text(1.25,cap[0]+(1.0 if fn=='cnn' else -1.0),name,color='#222',fontsize=8,va='center')
a.set_ylim(84,100); style(a,'Poultry: both feature sets','(c)'); a.set_ylabel('5-fold accuracy (%)')
a.text(100,90.5,'capture order (solid)\nrandom groups (dashed)',ha='right',fontsize=7.5,color='#555')
a=ax[1][1]
for ds,c,name in (('meat',BLUE,'red meat'),('poultry',AQUA,'poultry')):
    cur=G[ds]['curve']; x=[g for g,v,n in cur]; y=[v for g,v,n in cur]
    a.plot(x,y,lw=2,color=c,marker='o',ms=4); a.text(x[0]*1.15,y[0]+(-2.2 if ds=='meat' else 1.6),name,fontsize=8,color='#222')
a.set_xscale('log'); a.minorticks_off(); a.set_xticks([1,3,8,20,60,200]); a.set_xticklabels([1,3,8,20,60,200])
a.set_xlabel('Gap between file numbers'); a.set_ylabel('Mean pHash distance (bits)'); a.set_ylim(100,130)
a.set_title('Image similarity vs file order',fontsize=9); a.grid(axis='y',color='#e6e6e3',lw=0.6); a.set_axisbelow(True)
a.text(-0.17,1.07,'(d)',transform=a.transAxes,fontweight='bold')
fig.tight_layout(); fig.savefig('figs/fig_leakage_v8.png',dpi=300); print('ok')
